/*
 * Copyright (c) 2008-2012 GIANTS Software GmbH, Confidential, All Rights Reserved.
 * Copyright (c) 2003-2012 Christian Ammann and Stefan Geiger, Confidential, All Rights Reserved.
 */

precision mediump float;

uniform lowp sampler2D s_TexUnit0;
uniform lowp sampler2D s_TexUnit1;
uniform lowp sampler2D s_TexUnit2;
//uniform vec3 u_sLightAttenuation;
uniform vec3 u_sLightDiffuse;
uniform vec3 u_sLightDirection;
uniform vec2 u_sLightConeParams;
//uniform float u_sLightCutOff;
//uniform float u_sLightExponent;

varying mediump vec2 v_TexCoord0; // field texture
varying mediump vec2 v_TexCoord1; // weight map
varying mediump vec2 v_TexCoord2; // windrow texture
varying mediump vec3 v_Normal;
varying mediump vec3 v_Vertex;
varying lowp vec3 v_Color;

const lowp vec3 plowedColor = vec3(0.46093, 0.43459, 0.38281);
const lowp vec3 cultivatedColor = vec3(0.67968, 0.58984, 0.49609);

void main()
{
    vec3 VL = normalize(v_Vertex);

    lowp vec3 t_Color = v_Color;

    float spotCosAngle = dot(-VL, u_sLightDirection);
    //if (spotCosAngle >= u_sLightConeParams.y) {
        float spotFactor = clamp((spotCosAngle - u_sLightConeParams.y) * u_sLightConeParams.x, 0.0, 1.0);
        float ndotl = max( dot(v_Normal,VL)*0.8 + 0.2, 0.0);
        t_Color+=(ndotl*spotFactor)*u_sLightDiffuse;
    //}

    // ground specific code
    lowp vec2 tex0 = texture2D( s_TexUnit0, v_TexCoord0 ).rg; // Field Ground texture - only RG are used
    lowp vec4 weight = texture2D( s_TexUnit1, v_TexCoord1 ); // Weight Texture, (R, G, B, A) made on the fly
    //lowp vec4 weight = vec4(0.5, 0.5, 0, 0.4);
    lowp vec4 windrowTexture = texture2D(s_TexUnit2, v_TexCoord2);

    lowp vec3 groundColor = mix(cultivatedColor * tex0.g, plowedColor * tex0.r, weight.r) + vec3(weight.g);

	lowp float windrowAlpha = (windrowTexture.a*weight.a);
	lowp vec3 finalTextureColor = mix(groundColor, windrowTexture.xyz, windrowAlpha);

	gl_FragColor.xyz = finalTextureColor*t_Color;
}
