/*
 * Copyright (c) 2008-2012 GIANTS Software GmbH, Confidential, All Rights Reserved.
 * Copyright (c) 2003-2012 Christian Ammann and Stefan Geiger, Confidential, All Rights Reserved.
 */

precision mediump float;

uniform lowp samplerCube s_TexUnit0;
uniform lowp sampler2D s_TexUnit1;
uniform vec4 colorMask;
//uniform vec3 u_sLightAttenuation;
uniform vec3 u_sLightDiffuse;
uniform vec3 u_sLightDirection;
uniform vec2 u_sLightConeParams;
//uniform float u_sLightCutOff;
//uniform float u_sLightExponent;

varying mediump vec2 v_TexCoord0;
varying mediump vec3 v_Reflection;
varying mediump vec3 v_Normal;
varying mediump vec3 v_Vertex;
varying lowp vec3 v_Color;

void main()
{
    vec3 VL = normalize(v_Vertex);

    lowp vec3 t_Color = v_Color;

    float spotCosAngle = dot(-VL, u_sLightDirection);
    //if (spotCosAngle >= u_sLightConeParams.y) {
        float spotFactor = clamp((spotCosAngle - u_sLightConeParams.y) * u_sLightConeParams.x, 0.0, 1.0);
        float ndotl = max( dot(v_Normal,VL)*0.8 + 0.2, 0.0);
        t_Color+=(ndotl*spotFactor)*u_sLightDiffuse;
    //}

    lowp vec3 tex0=textureCube(s_TexUnit0,v_Reflection).xyz;
    lowp vec3 tex1=texture2D(s_TexUnit1,v_TexCoord0).xyz;

    gl_FragColor.xyz = t_Color*tex1*colorMask.rgb + tex0*colorMask.a;
}
