/*
 * Copyright (c) 2008-2012 GIANTS Software GmbH, Confidential, All Rights Reserved.
 * Copyright (c) 2003-2012 Christian Ammann and Stefan Geiger, Confidential, All Rights Reserved.
 */

precision highp float;
precision mediump int;

uniform vec4 uvOffset;
uniform mat4 u_mvMatrix;
uniform mat4 u_mvpMatrix;
uniform vec3 u_dLightAmbient;
uniform vec3 u_dLightDiffuse;
uniform	vec3 u_dLightDirection;
uniform	vec4 u_sLightPosition;

attribute vec3 Position;
attribute vec4 Normal;
attribute vec2 TexCoord0;

varying mediump vec2 v_TexCoord0;
varying mediump vec3 v_Normal;
varying mediump vec3 v_Vertex;
varying lowp vec3 v_Color;

void main()
{
    v_TexCoord0 = TexCoord0.xy+uvOffset.xy;

    vec4 pos=vec4(Position,1.0);
    gl_Position = u_mvpMatrix * pos; 

	v_Normal = normalize((u_mvMatrix * vec4(Normal.xyz,0.0)).xyz);
    v_Vertex = u_sLightPosition.xyz -(u_mvMatrix * pos).xyz;  

    // diffuse lighting  
    float diff = max( dot(v_Normal,-u_dLightDirection), 0.0);
    v_Color = (diff*u_dLightDiffuse) + u_dLightAmbient;

    // switch coords to landscape mode for iphone
#ifdef SWITCH_XY
    gl_Position.xy=vec2(gl_Position.y, -gl_Position.x);
#endif
}
