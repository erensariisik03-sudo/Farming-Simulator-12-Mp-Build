/*
 * Copyright (c) 2008-2012 GIANTS Software GmbH, Confidential, All Rights Reserved.
 * Copyright (c) 2003-2012 Christian Ammann and Stefan Geiger, Confidential, All Rights Reserved.
 */

precision mediump float;

// varying for fragmet shader

varying mediump vec2 v_TexCoord0;
varying lowp vec4 v_Color;

uniform sampler2D s_TexUnit0;

void main()
{
    gl_FragColor = texture2D(s_TexUnit0, v_TexCoord0).xxxx * v_Color;
}
