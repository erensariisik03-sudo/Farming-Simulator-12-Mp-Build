/*
 * Copyright (c) 2008-2012 GIANTS Software GmbH, Confidential, All Rights Reserved.
 * Copyright (c) 2003-2012 Christian Ammann and Stefan Geiger, Confidential, All Rights Reserved.
 */

precision highp float;
precision mediump int;

attribute vec3 Position;


varying mediump vec2 v_TexCoord0;
varying lowp vec4 v_Color;

uniform vec3 u_RotationAndScale;
uniform vec4 u_Color;
//uniform mat4 u_mvpMatrix;
uniform vec4 u_TexVecs;
uniform vec4 u_CoordVecs;

//const float aspect=320.0/480.0;

void main()
{
    v_TexCoord0=(Position.xy*u_TexVecs.zw)+u_TexVecs.xy;
    v_Color=u_Color;

    gl_Position = vec4(Position.xyz, 1.0);
    gl_Position.xy=(gl_Position.xy*u_CoordVecs.zw);

    if (u_RotationAndScale.x != 0.0) {
        float ca=cos(u_RotationAndScale.x);
        float sa=sin(u_RotationAndScale.x);

        gl_Position.xy -= u_CoordVecs.zw*0.5;
        gl_Position.x *= u_RotationAndScale.z; // undo aspect ratio (xy=1,1 is square)
        gl_Position.xy = vec2((gl_Position.x*ca)-(gl_Position.y*sa), (gl_Position.x*sa)+(gl_Position.y*ca));
        gl_Position.x *= u_RotationAndScale.y; // apply aspect ratio (xy=aspect,1 is square)
        gl_Position.xy += u_CoordVecs.zw*0.5;
    }
    gl_Position.xy += u_CoordVecs.xy;

    // switch coords to landscape mode for iphone
#ifdef SWITCH_XY
    gl_Position.xy=vec2(gl_Position.y, -gl_Position.x);
#endif
}
