/*
 * Copyright (c) 2008-2012 GIANTS Software GmbH, Confidential, All Rights Reserved.
 * Copyright (c) 2003-2012 Christian Ammann and Stefan Geiger, Confidential, All Rights Reserved.
 */

precision highp float;
precision mediump int;

uniform mat4 u_mvMatrix;
uniform mat4 u_mvpMatrix;
uniform vec3 u_dLightAmbient;
uniform vec3 u_dLightDiffuse;
uniform vec3 u_dLightDirection;
uniform vec4 u_sLightPosition;
//uniform vec3 u_sLightAttenuation;
uniform vec3 u_sLightDiffuse;
uniform vec3 u_sLightDirection;
uniform vec2 u_sLightConeParams;
//uniform float u_sLightCutOff;
//uniform float u_sLightExponent;

attribute vec3 Position;
attribute vec4 Normal;
attribute vec2 TexCoord0;

varying mediump vec2 v_TexCoord0;
varying lowp vec3 v_Color;

void main()
{
    v_TexCoord0 = TexCoord0;
    gl_Position = u_mvpMatrix * vec4(Position,1.0); 

	vec3 N = normalize((u_mvMatrix * vec4(Normal.xyz,0.0)).xyz);
    //V = u_sLightPosition.xyz -vec3( u_mvMatrix * pos);
    //len=length(V);
    //VL=V/len;

    vec3 VL = normalize(u_sLightPosition.xyz -(u_mvMatrix * vec4(Position,1.0)).xyz);

    float spotCosAngle = dot(-VL, u_sLightDirection);
    float spotFactor = clamp((spotCosAngle - u_sLightConeParams.y) * u_sLightConeParams.x, 0.0, 1.0);
    float ndotlSpot = max( dot(N,VL)*0.8 + 0.2, 0.0);
    v_Color = (ndotlSpot*spotFactor)*u_sLightDiffuse;

    // directional diffuse lighting
    float ndotl = max( dot(N,-u_dLightDirection), 0.0);
    v_Color += (ndotl*u_dLightDiffuse) + u_dLightAmbient;

    // switch coords to landscape mode for iphone
#ifdef SWITCH_XY
    gl_Position.xy=vec2(gl_Position.y, -gl_Position.x);
#endif
}
