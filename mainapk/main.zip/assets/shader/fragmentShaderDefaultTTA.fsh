/*
 * Copyright (c) 2008-2012 GIANTS Software GmbH, Confidential, All Rights Reserved.
 * Copyright (c) 2003-2012 Christian Ammann and Stefan Geiger, Confidential, All Rights Reserved.
 */

precision mediump float;

uniform lowp sampler2D s_TexUnit0;
uniform	vec3 u_sLightDiffuse;
uniform	vec3 u_sLightDirection;
uniform vec2 u_sLightConeParams;

varying mediump vec2 v_TexCoord0;
varying mediump vec3 v_Normal;
varying mediump vec3 v_Vertex;
varying lowp vec3 v_Color;

void main()
{
    vec3 VL = normalize(v_Vertex);
    lowp vec3 t_Color = v_Color;

    float spotCosAngle = dot(-VL, u_sLightDirection);
    float spotFactor = clamp((spotCosAngle - u_sLightConeParams.y) * u_sLightConeParams.x, 0.0, 1.0);
    float ndotl = max( dot(v_Normal,VL)*0.8 + 0.2, 0.0);
    t_Color += (ndotl*spotFactor)*u_sLightDiffuse;

    vec2 colorCoord = v_TexCoord0;
    colorCoord.y /= 2.0;

    vec2 alphaCoord = vec2(colorCoord.x, colorCoord.y + 0.5);

    lowp vec4 texel = texture2D(s_TexUnit0, colorCoord);
    texel.a = texture2D(s_TexUnit0, alphaCoord).g;

    gl_FragColor = texel*vec4(t_Color,1.0);
}

