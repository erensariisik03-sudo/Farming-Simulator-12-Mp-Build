/*
 * Copyright (c) 2008-2012 GIANTS Software GmbH, Confidential, All Rights Reserved.
 * Copyright (c) 2003-2012 Christian Ammann and Stefan Geiger, Confidential, All Rights Reserved.
 */

precision mediump float;

uniform lowp sampler2D s_TexUnit0;

varying mediump vec2 v_TexCoord0;
varying lowp vec3 v_Color;

#define USE_ALPHA_TESTING

void main()
{
    lowp vec4 texel=texture2D( s_TexUnit0, v_TexCoord0 );
#if defined(USE_ALPHA_TESTING)
    if (texel.a<=0.5) {
        discard;
    }
    gl_FragColor.xyz = texel.xyz*v_Color;
#else
    gl_FragColor = vec4(texel.xyz*v_Color, floor(texel.a+0.5));
#endif
}
